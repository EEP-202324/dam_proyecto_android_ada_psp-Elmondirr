package com.example.escaneo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContadorDeEntradasApplicationTests {

	@Test
	void contextLoads() {
	}

}
