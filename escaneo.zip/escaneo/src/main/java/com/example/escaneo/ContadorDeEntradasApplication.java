package com.example.escaneo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContadorDeEntradasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContadorDeEntradasApplication.class, args);
	}

}
